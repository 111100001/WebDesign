document.getElementById("chatForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    const userInput = document.getElementById("userInput").value;
    if (!userInput.trim()) return;
  
    document.getElementById("userInput").value = "";
    const chatBox = document.getElementById("chatBox");
  
    // Show loading
    const loadingDiv = document.createElement("div");
    loadingDiv.textContent = "DeepSeek is typing...";
    loadingDiv.id = "loading";
    chatBox.appendChild(loadingDiv);
  
    const apiKey = "sk-2b6e27d344a7484580fbb08a975a67c7";
  
    try {
      const res = await fetch("https://api.deepseek.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: "deepseek-chat",
          messages: [{ role: "user", content: userInput }]
        })
      });
  
      if (!res.ok) throw new Error("API request failed");
  
      const data = await res.json();
      loadingDiv.remove();
      displayFullReply(data, userInput);
    } catch (err) {
      loadingDiv.remove();
      const errorDiv = document.createElement("div");
      errorDiv.textContent = "Error: " + err.message;
      chatBox.appendChild(errorDiv);
    }
  });
  
  document.getElementById("clearBtn").addEventListener("click", () => {
    document.getElementById("chatBox").innerHTML = "";
  });
  
  function displayFullReply(data, userInput) {
    const reply = data.choices[0].message.content;
    const model = data.model;
    const tokens = data.usage.total_tokens;
    const timestamp = new Date().toLocaleString();
  
    const container = document.createElement("div");
    container.innerHTML = `
      <p><strong>You:</strong> ${userInput}</p>
      <p><strong>DeepSeek:</strong> ${reply}</p>
      <p><strong>Model:</strong> ${model}</p>
      <p><strong>Total Tokens Used:</strong> ${tokens}</p>
      <p><strong>Time:</strong> ${timestamp}</p>
    `;
    document.getElementById("chatBox").appendChild(container);
  }
  